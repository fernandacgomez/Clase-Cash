// Motocicleta hereda atributos y métodos de Vehiculo.
// "implements Combustible" significa que Motocicleta debe definir cómo recargar y obtener combustible.
public class Motocicleta extends Vehiculo implements Combustible, Mantenimiento {
    private double nivelCombustible;
    private int cilindrada;

    public Motocicleta(String marca, String modelo, int anio, double nivelCombustible, int cilindrada) {
        super(marca, modelo, anio);
        this.nivelCombustible = nivelCombustible;
        this.cilindrada = cilindrada;
    }

    @Override
    public void mover() {
        if (nivelCombustible > 0) {
            System.out.println("La motocicleta " + getMarca() + " " + getModelo() +
                    " está acelerando con " + cilindrada + " cc.");
            nivelCombustible -= 0.3;
        } else {
            System.out.println("La motocicleta " + getMarca() + " " + getModelo() + " no tiene combustible.");
        }
    }

    @Override
    public String obtenerDetalles() {
        return super.obtenerDetalles() + ", Combustible: " + nivelCombustible +
                " litros, Cilindrada: " + cilindrada + " cc";
    }

    @Override
    public void recargarCombustible() {
        nivelCombustible = 20.0;
        System.out.println("La motocicleta " + getMarca() + " " + getModelo() +
                " ha sido recargada con combustible.");
    }

    @Override
    public double obtenerNivelCombustible() {
        return nivelCombustible;
    }

    @Override
    public void realizarMantenimiento() {
        System.out.println("Cambiando aceite de la motocicleta " + getMarca() + " " + getModelo() + ".");
    }

}

public interface Combustible {
    void recargarCombustible();
    double obtenerNivelCombustible();
}

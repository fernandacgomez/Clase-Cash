public class SistemaVehiculos {

    // Recorre el arreglo y aplica polimorfismo + interfaces
    public static void procesarVehiculos(Vehiculo[] vehiculos) {
        for (Vehiculo v : vehiculos) {
            v.mover();
            System.out.println(v.obtenerDetalles());

            if (v instanceof Combustible) {
                System.out.println("Nivel de combustible: " + ((Combustible) v).obtenerNivelCombustible());
                ((Combustible) v).recargarCombustible();
            }

            if (v instanceof Mantenimiento) {
                ((Mantenimiento) v).realizarMantenimiento();
            }
        }
    }

    public static void main(String[] args) {
        // Instancias
        Vehiculo auto = new Automovil("Toyota", "Corolla", 2020, 40.0);
        Vehiculo bici = new Bicicleta("Trek", "Mountain", 2022, 21);
        Vehiculo moto = new Motocicleta("Honda", "CBR", 2023, 10.0, 250);

        // Pruebas individuales
        auto.mover();
        System.out.println(auto.obtenerDetalles());
        ((Combustible) auto).recargarCombustible();
        System.out.println("Nivel de combustible: " + ((Combustible) auto).obtenerNivelCombustible());

        bici.mover();
        System.out.println(bici.obtenerDetalles());

        moto.mover();
        System.out.println(moto.obtenerDetalles());
        ((Combustible) moto).recargarCombustible();
        System.out.println("Nivel de combustible: " + ((Combustible) moto).obtenerNivelCombustible());

        // Polimorfismo avanzado¿ procesar todos juntos
        System.out.println("== Procesando todos los vehículos ==");
        Vehiculo[] lista = { auto, bici, moto };
        procesarVehiculos(lista);
    }
}

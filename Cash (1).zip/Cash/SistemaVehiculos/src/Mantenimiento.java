public interface Mantenimiento {
    void realizarMantenimiento();
}
